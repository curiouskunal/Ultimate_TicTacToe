# Module Interface Specification #

Using [JsDoc](https://github.com/jsdoc3/jsdoc) 

#### How To Generate MIS

```
$ cd ../../../scr
$ npm install jsdoc
$ ./node_modules/.bin/jsdoc lib/script.js -d ../../Doc/Design/MIS
$ open ../../Doc/Design/MIS/index.html
```

